package com.pancho.modelo;

public class Empleado {
    private int codigo;
    private String nombres;
    private String apellidos;

    public double[] getVentasMes() {
        return ventasMes;
    }

    public void setVentasMes(double[] ventasMes) {
        this.ventasMes = ventasMes;
    }

    private String email;
    private String celular;
    private int categoria;
    private double sueldoBase;
    private double[] ventasMes;

    // Constructor
    public Empleado(int codigo, String nombres, String apellidos, String email, String celular, int categoria, double sueldoBase) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.email = email;
        this.celular = celular;
        this.categoria = categoria;
        this.sueldoBase = sueldoBase;
        this.ventasMes = new double[12]; // Inicializamos el arreglo para las ventas de cada mes
    }

    // Getters y setters
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public double getSueldoBase() {
        return sueldoBase;
    }

    public void setSueldoBase(double sueldoBase) {
        this.sueldoBase = sueldoBase;
    }

    // Método para calcular el salario mensual
    public double calcularSalarioMensual(int mes) {
        double totalVentas = this.ventasMes[mes - 1]; // Restamos 1 para ajustar el índice del mes al arreglo (Enero=0, Febrero=1, etc.)
        return this.sueldoBase + (totalVentas * calcularComision(totalVentas));
    }

    // Método para calcular el salario anual
    public double calcularSalarioAnual() {
        double salarioAnual = 0;
        for (double ventas : this.ventasMes) {
            salarioAnual += this.sueldoBase + (ventas * calcularComision(ventas));
        }
        return salarioAnual;
    }

    // Método para calcular la comisión según las ventas mensuales
    private double calcularComision(double ventas) {
        double comision = 0;

        if (ventas >= 50 && ventas <= 99) {
            switch (this.categoria) {
                case 1:
                    comision = 0.02;
                    break;
                case 2:
                    comision = 0.05;
                    break;
                case 3:
                    comision = 0.1;
                    break;
            }
        } else if (ventas >= 100 && ventas <= 199) {
            switch (this.categoria) {
                case 1:
                    comision = 0.05;
                    break;
                case 2:
                    comision = 0.1;
                    break;
                case 3:
                    comision = 0.15;
                    break;
            }
        } else if (ventas >= 200) {
            switch (this.categoria) {
                case 1:
                    comision = 0.1;
                    break;
                case 2:
                    comision = 0.15;
                    break;
                case 3:
                    comision = 0.2;
                    break;
            }
        }

        return comision;
    }

    // Método toString para imprimir el contenido del objeto
    @Override
    public String toString() {
        return "Empleado{" +
                "codigo=" + codigo +
                ", nombres='" + nombres + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", email='" + email + '\'' +
                ", celular='" + celular + '\'' +
                ", categoria=" + categoria +
                ", sueldoBase=" + sueldoBase +
                '}';
    }
}
