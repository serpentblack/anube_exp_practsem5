package com.pancho;

import java.util.*;


import com.pancho.modelo.Empleado;

public class TiendaDonPancho {
    private ArrayList<Empleado> empleados;

    public TiendaDonPancho() {
        this.empleados = new ArrayList<>(Arrays.asList(
                new Empleado(1, "Juan", "Perez", "juan@example.com", "123456789", 1, 2000),
                new Empleado(2, "Maria", "Gomez", "maria@example.com", "987654321", 2, 1800),
                new Empleado(3, "Pedro", "Martinez", "pedro@example.com", "567890123", 1, 2200),
                new Empleado(4, "Laura", "Rodriguez", "laura@example.com", "321654987", 3, 2500),
                new Empleado(5, "Carlos", "Lopez", "carlos@example.com", "789012345", 2, 1900),
                new Empleado(6, "Ana", "Sanchez", "ana@example.com", "456789012", 1, 2100),
                new Empleado(7, "Pablo", "Hernandez", "pablo@example.com", "901234567", 3, 2400),
                new Empleado(8, "Lucia", "Diaz", "lucia@example.com", "234567890", 2, 2000),
                new Empleado(9, "Sofia", "Alvarez", "sofia@example.com", "678901234", 1, 2300),
                new Empleado(10, "Diego", "Garcia", "diego@example.com", "012345678", 3, 2600)
        ));

        // Generar valores de ingreso mensual aleatorios para cada empleado
        Random random = new Random();
        for (Empleado empleado : empleados) {
            double[] ventasMes = empleado.getVentasMes();
            for (int i = 0; i < ventasMes.length; i++) {
                ventasMes[i] = random.nextInt(451) + 50; // Entre 50 y 500 unidades
            }
        }
    }

    public void registrarEmpleado() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el código del empleado:");
        int codigo = scanner.nextInt();
        System.out.println("Ingrese los nombres del empleado:");
        String nombres = scanner.next();
        System.out.println("Ingrese los apellidos del empleado:");
        String apellidos = scanner.next();
        System.out.println("Ingrese el email del empleado:");
        String email = scanner.next();
        System.out.println("Ingrese el número de celular del empleado:");
        String celular = scanner.next();
        System.out.println("Ingrese la categoría del empleado (1, 2 o 3):");
        int categoria = scanner.nextInt();
        System.out.println("Ingrese el sueldo base del empleado:");
        double sueldoBase = scanner.nextDouble();

        Empleado empleado = new Empleado(codigo, nombres, apellidos, email, celular, categoria, sueldoBase);
        this.empleados.add(empleado);

        System.out.println("Empleado registrado con éxito.");
    }

    public void borrarEmpleado() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el código del empleado que desea borrar:");
        int codigo = scanner.nextInt();

        for (Empleado empleado : this.empleados) {
            if (empleado.getCodigo() == codigo) {
                this.empleados.remove(empleado);
                System.out.println("Empleado borrado con éxito.");
                return;
            }
        }

        System.out.println("No se encontró ningún empleado con el código ingresado.");
    }

    public void consultarEmpleado() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el código del empleado que desea consultar:");
        int codigo = scanner.nextInt();

        for (Empleado empleado : this.empleados) {
            if (empleado.getCodigo() == codigo) {
                System.out.println(empleado);
                return;
            }
        }

        System.out.println("No se encontró ningún empleado con el código ingresado.");
    }

    public void registrarValorIngresoMensual() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el código del empleado:");
        int codigo = scanner.nextInt();
        System.out.println("Ingrese el número del mes (1 - Enero, 2 - Febrero, etc.):");
        int mes = scanner.nextInt();
        System.out.println("Ingrese la cantidad de productos vendidos:");
        double ventas = scanner.nextDouble();

        for (Empleado empleado : this.empleados) {
            if (empleado.getCodigo() == codigo) {
                empleado.getVentasMes()[mes - 1] = ventas; // Restamos 1 para ajustar el índice del mes al arreglo
                System.out.println("Valor ingreso mensual registrado con éxito.");
                return;
            }
        }

        System.out.println("No se encontró ningún empleado con el código ingresado.");
    }

    public void menuReportes() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("TIENDA DON PANCHO");
            System.out.println("Reportes");
            System.out.println("1. Empleado con más sueldo.");
            System.out.println("2. Total de sueldos pagado en cada categoría.");
            System.out.println("3. Cantidad de empleados en cada categoría.");
            System.out.println("4. Volver al menú principal.");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // Lógica para el reporte del empleado con más sueldo
                    Empleado empleadoConMasSueldo = empleadoConMasSueldo();
                    if (empleadoConMasSueldo != null) {
                        System.out.println("Empleado con más sueldo:");
                        System.out.println(empleadoConMasSueldo);
                        System.out.println("Sueldo anual: $" + empleadoConMasSueldo.calcularSalarioAnual());
                    } else {
                        System.out.println("No hay empleados registrados.");
                    }
                    break;
                case 2:
                    // Lógica para el reporte del total de sueldos pagado en cada categoría
                    Map<Integer, Double> totalSueldosPorCategoria = reporteTotalSueldosPorCategoria();
                    if (!totalSueldosPorCategoria.isEmpty()) {
                        System.out.println("Total de sueldos pagado en cada categoría:");
                        totalSueldosPorCategoria.forEach((categoria, totalSueldo) ->
                                System.out.println("Categoría " + categoria + ": $" + totalSueldo));
                    } else {
                        System.out.println("No hay empleados registrados.");
                    }
                    break;
                case 3:
                    // Lógica para el reporte de la cantidad de empleados en cada categoría
                    Map<Integer, Integer> cantidadEmpleadosPorCategoria = reporteCantidadEmpleadosPorCategoria();
                    if (!cantidadEmpleadosPorCategoria.isEmpty()) {
                        System.out.println("Cantidad de empleados en cada categoría:");
                        cantidadEmpleadosPorCategoria.forEach((categoria, cantidadEmpleados) ->
                                System.out.println("Categoría " + categoria + ": " + cantidadEmpleados + " empleados"));
                    } else {
                        System.out.println("No hay empleados registrados.");
                    }
                    break;
                case 4:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 4);
    }

    //Métodos para los reportes

    // Método para obtener el empleado con más sueldo
    public Empleado empleadoConMasSueldo() {
        if (this.empleados.isEmpty()) {
            return null;
        }

        Empleado empleadoConMasSueldo = this.empleados.get(0);
        for (Empleado empleado : this.empleados) {
            if (empleado.calcularSalarioAnual() > empleadoConMasSueldo.calcularSalarioAnual()) {
                empleadoConMasSueldo = empleado;
            }
        }

        return empleadoConMasSueldo;
    }

    // Método para generar el reporte del total de sueldos pagado en cada categoría
    public Map<Integer, Double> reporteTotalSueldosPorCategoria() {
        Map<Integer, Double> totalSueldosPorCategoria = new HashMap<>();
        for (Empleado empleado : this.empleados) {
            int categoria = empleado.getCategoria();
            double salarioAnual = empleado.calcularSalarioAnual();
            totalSueldosPorCategoria.put(categoria, totalSueldosPorCategoria.getOrDefault(categoria, 0.0) + salarioAnual);
        }
        return totalSueldosPorCategoria;
    }

    // Método para generar el reporte de la cantidad de empleados en cada categoría
    public Map<Integer, Integer> reporteCantidadEmpleadosPorCategoria() {
        Map<Integer, Integer> cantidadEmpleadosPorCategoria = new HashMap<>();
        for (Empleado empleado : this.empleados) {
            int categoria = empleado.getCategoria();
            cantidadEmpleadosPorCategoria.put(categoria, cantidadEmpleadosPorCategoria.getOrDefault(categoria, 0) + 1);
        }
        return cantidadEmpleadosPorCategoria;
    }
    /**
     * Método main de la aplicación
     * @param args
     */
    public static void main(String[] args) {
        TiendaDonPancho app = new TiendaDonPancho();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("TIENDA DON PANCHO");
            System.out.println("Menú Principal");
            System.out.println("1. Registrar empleado.");
            System.out.println("2. Borrar empleado.");
            System.out.println("3. Consultar empleado.");
            System.out.println("4. Registrar valor ingreso mensual (Nomina).");
            System.out.println("5. Reportes.");
            System.out.println("6. Terminar.");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    app.registrarEmpleado();
                    break;
                case 2:
                    // Lógica para borrar un empleado
                    app.borrarEmpleado();
                    break;
                case 3:
                    // Lógica para consultar un empleado
                    app.consultarEmpleado();
                    break;
                case 4:
                    // Lógica para registrar valor ingreso mensual
                    app.registrarValorIngresoMensual();
                    break;
                case 5:
                    // Lógica para los reportes
                    app.menuReportes();
                    break;
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 6);

        scanner.close();
    }
}
