package com.abd.test;

import com.abd.modelo.MaquinaExpendedora;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        MaquinaExpendedora maquina = new MaquinaExpendedora();
        Scanner scanner = new Scanner(System.in);

        int opcion;
        do {
            System.out.println("\nMenú de la Máquina Expendedora");
            System.out.println("1. Pedir comestible");
            System.out.println("2. Mostrar comestibles disponibles");
            System.out.println("3. Rellenar comestibles");
            System.out.println("4. Apagar máquina");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese la posición del comestible (fila columna): ");
                    int fila = scanner.nextInt();
                    int columna = scanner.nextInt();
                    maquina.pedirComestible(fila, columna);
                    break;
                case 2:
                    maquina.mostrarComestibles();
                    break;
                case 3:
                    System.out.println("Ingrese la contraseña: ");
                    String contraseña = scanner.next();
                    maquina.llenarBandeja(contraseña);
                    break;
                case 4:
                    maquina.apagarMaquina();
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 4);
    }
}