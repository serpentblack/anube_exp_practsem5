package com.abd.modelo;
import java.util.Scanner;
import java.util.Random;

public class MaquinaExpendedora {
    private Comestible[][] bandeja;
    private double ventasTotales;

    public MaquinaExpendedora() {
        // Inicializar la bandeja con comestibles vacíos
        bandeja = new Comestible[5][5];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                bandeja[i][j] = new Comestible("Comestible vacío", 0.0, 0);
            }
        }

        llenarBandejas();
    }

    public void llenarBandejas() {
        String[] nombresComestibles = {"Galletas", "Chocolate", "Snacks", "Bebida", "Frutas"};
        double[] preciosComestibles = {1.5, 2.0, 1.0, 1.75, 0.75};

        Random random = new Random();

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                int cantidadInicial = random.nextInt(6) + 5; // Generar cantidad aleatoria entre 5 y 10
                int indiceComestible = random.nextInt(nombresComestibles.length); // Seleccionar aleatoriamente un comestible
                bandeja[i][j] = new Comestible(nombresComestibles[indiceComestible], preciosComestibles[indiceComestible], cantidadInicial);
            }
        }
    }
    public void llenarBandeja(String contraseña) {
        Scanner scanner = new Scanner(System.in);
        if (contraseña.equals("MaquinaExpendedora2017")) {
            System.out.println("Ingrese la posición del comestible (fila columna): ");
            int fila = scanner.nextInt();
            int columna = scanner.nextInt();
            System.out.println("Ingrese la cantidad de comestibles a agregar: ");
            int cantidad = scanner.nextInt();
            bandeja[fila][columna].disminuirCantidad();
            System.out.println("Comestibles agregados correctamente.");
        } else {
            System.out.println("Contraseña incorrecta. Acceso denegado.");
        }
    }

    public void mostrarComestibles() {
        System.out.println("Comestibles disponibles:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.println("Posición: " + i + j);
                System.out.println("Nombre: " + bandeja[i][j].getNombre());
                System.out.println("Precio: " + bandeja[i][j].getPrecio());
            }
        }
    }

    public void pedirComestible(int fila, int columna) {
        if (bandeja[fila][columna].getCantidad() > 0) {
            System.out.println("Ha comprado un " + bandeja[fila][columna].getNombre() + " por $" + bandeja[fila][columna].getPrecio());
            ventasTotales += bandeja[fila][columna].getPrecio();
            bandeja[fila][columna].disminuirCantidad();
        } else {
            System.out.println("No hay más comestibles en esta posición.");
        }
    }

    public void apagarMaquina() {
        System.out.println("Ventas totales durante la ejecución del programa: $" + ventasTotales);
        System.out.println("Apagando la máquina expendedora...");
    }
}